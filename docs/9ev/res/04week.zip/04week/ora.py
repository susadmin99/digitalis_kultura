for alma in "Alma":
    print(alma)

for korte in range(10):
    print(korte)

for eper in range(10,20):
    print(eper)

for repa in range(10,50,2):
    print(repa)
else:
    print("Vége")



x = 10
while x < 20:
    print(x)
    x+=1
else:
    print("Vége")
    